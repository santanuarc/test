Class: Html2PdfReport
======================================================
This class generates PDF Report from HTML.

Here's how it works:

- Gets URL that will be converted to PDF
- Creates PDF report for that URL by using remote application

For Remote PDF Application, I have used html2ps and html2pdf (supplied by http://www.tufat.com/script19.htm). 
It is 100% FREE for commercial AND non-commercial use! It renders pages as PDF documents and PostScript files. 
I have deployed this application to phpResource(http://groups.yahoo.com/group/phpresource/) group's server 
for easy and reliable access. My special thanks goes to phpResource group.  


And Me:
I am a hardcore C/C++ and PHP programmer. I enjoy my times in implementing varities of freelancing works. 

Please rate this class if you like and if it comes to your needs. Please feel free to contact me for 
any suggestion and/or further assistance regarding the technique and its implementation.

==============================================================================
MA Razzaque Rupom
Moderator, phpResource Group
http://groups.yahoo.com/group/phpresource/
My Blog : http://www.rupom.info
Emails:
rupom_315@yahoo.com
rupom.bd@gmail.com
