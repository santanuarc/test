# PHRETS Example

An example pack to get started using [PHRETS](https://github.com/troydavisson/PHRETS).

Full tutorial can be found [here](http://dangodesign.net/2013/01/getting-started-with-rets-for-php/)