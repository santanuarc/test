/*
 * Copyright 1999 - 2011 Crazy Development Ltd.
 *
 * The code and all underlying concepts and data models are owned fully
 * and exclusively by Crazy Development Ltd. and are protected by
 * copyright law and international treaties.
 *
 * Warning: Unauthorized reproduction, use or distribution of this
 * program, concepts, documentation and data models, or any portion of
 * it, may result in severe civil and criminal penalties, and will be
 * prosecuted to the maximum extent possible under the law.
 */

vizDoc = {};
vizDoc.url = "http://localhost:8282/icCube/gvi";
vizDoc.user = "demo";
vizDoc.pwd = "demo";
vizDoc.schema = "Sales";
vizDoc.cube = "Sales";
