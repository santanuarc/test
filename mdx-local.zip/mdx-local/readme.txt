icCube - README


starting icCube => ./bin directory


starting UI => open a browser : http://localhost:8282/icCube/icCube.html


__
